from __future__ import annotations

from typing import Any, Dict, List, Optional

from .compiler import GeometryCompiler
from .graph import GeometryGraph
from .reasoner import CandidateSolution, GeometrySearcher
from .verifier import GeometryVerifier


class GeometryMemory:
    def __init__(self) -> None:
        self.templates = [
            {
                "name": "circle_to_rectangle_area_preservation",
                "task": "circle_to_square_area_preservation",
                "similarity": 0.95,
                "program": ["partition_circle", "linearize_arcs", "reassemble_strips", "verify_area"],
            },
            {
                "name": "symmetry_detection_template",
                "task": "symmetry_detection",
                "similarity": 0.85,
                "program": ["detect_axis", "validate_reflection"],
            },
        ]

    def query(self, task: str) -> List[Dict[str, Any]]:
        hits = [t for t in self.templates if t["task"] == task]
        if not hits:
            hits = [{"name": "generic_template", "task": task, "similarity": 0.2, "program": ["inspect"]}]
        return hits


class ProofTracer:
    def trace(self, program: List[str]) -> List[str]:
        traces = []
        for step in program:
            if step == "partition_circle":
                traces.append("Circle is partitioned into sectors.")
            elif step == "linearize_arcs":
                traces.append("Circular arcs are approximated by straight segments.")
            elif step == "reassemble_strips":
                traces.append("Segments are rearranged into an equal-area strip-like form.")
            elif step == "verify_area":
                traces.append("Circle area is matched against square area.")
            elif step == "detect_axis":
                traces.append("Candidate symmetry axes are inferred from the structure.")
            elif step == "validate_reflection":
                traces.append("Reflection invariance is checked against the candidate axis.")
            else:
                traces.append(f"Executed {step}.")
        return traces


class TextRenderer:
    def render(self, result: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "task": result.get("task", "unknown"),
            "answer": result.get("answer", ""),
            "proof": result.get("proof", []),
            "valid": result.get("valid", False),
            "score": result.get("score", 0.0),
            "explanation": result.get("explanation", ""),
        }


class GeometryNativeLLM:
    def __init__(self) -> None:
        self.compiler = GeometryCompiler()
        self.memory = GeometryMemory()
        self.searcher = GeometrySearcher()
        self.verifier = GeometryVerifier()
        self.proof = ProofTracer()
        self.renderer = TextRenderer()

    def solve(self, raw_input: str) -> Dict[str, Any]:
        compiled = self.compiler.compile(raw_input)
        graph: GeometryGraph = compiled["graph"]
        task = compiled["task"]
        confidence = compiled["confidence"]

        hits = self.memory.query(task)
        candidates = self.searcher.propose(graph, task, hits)

        best: Optional[CandidateSolution] = None
        for candidate in candidates:
            program_names = [step.op for step in candidate.program]
            report = self.verifier.verify(graph, program_names)
            proof = self.proof.trace(program_names)

            similarity = max((h.get("similarity", 0.0) for h in hits), default=0.0)
            validity = 1.0 if report.valid else 0.0
            proof_strength = min(1.0, len(proof) / 4.0)
            cost = sum(step.cost for step in candidate.program)
            uncertainty = 1.0 - confidence

            candidate.valid = report.valid
            candidate.proof = proof
            candidate.score = self.searcher.score_candidate(
                candidate,
                validity=validity,
                proof_strength=proof_strength,
                similarity=similarity,
                cost=cost,
                uncertainty=uncertainty,
            )
            candidate.explanation = "; ".join(report.notes) if report.notes else candidate.explanation

            if best is None or candidate.score > best.score:
                best = candidate

        if best is None:
            return {"error": "No candidate solution found"}

        if task == "circle_to_square_area_preservation":
            c1 = next((n for n in graph.nodes if n.id == "c1"), None)
            s1 = next((n for n in graph.nodes if n.id == "s1"), None)
            answer = (
                f"Area preserved. Circle area = {c1.props['area']:.6f}, "
                f"square side = {s1.props['side']:.6f}."
            )
        elif task == "symmetry_detection":
            answer = "Symmetry analysis completed using candidate axes."
        elif task == "containment_reasoning":
            answer = "Containment relation compiled and verified."
        else:
            answer = "Generic geometric reasoning completed."

        result = {
            "task": task,
            "answer": answer,
            "proof": best.proof,
            "valid": best.valid,
            "score": round(best.score, 4),
            "explanation": best.explanation,
            "graph": graph.to_dict(),
            "candidate_program": [step.op for step in best.program],
        }
        rendered = self.renderer.render(result)
        rendered["graph"] = result["graph"]
        rendered["candidate_program"] = result["candidate_program"]
        return rendered
