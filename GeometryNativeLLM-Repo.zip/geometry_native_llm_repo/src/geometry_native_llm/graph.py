from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class GeoNode:
    id: str
    type: str
    props: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0


@dataclass
class GeoEdge:
    source: str
    target: str
    type: str
    props: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GeoConstraint:
    kind: str
    subject: str
    target: Optional[str] = None
    params: Dict[str, Any] = field(default_factory=dict)
    hard: bool = True
    weight: float = 1.0


@dataclass
class GeometryGraph:
    nodes: List[GeoNode] = field(default_factory=list)
    edges: List[GeoEdge] = field(default_factory=list)
    constraints: List[GeoConstraint] = field(default_factory=list)

    def node_map(self) -> Dict[str, GeoNode]:
        return {n.id: n for n in self.nodes}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [asdict(n) for n in self.nodes],
            "edges": [asdict(e) for e in self.edges],
            "constraints": [asdict(c) for c in self.constraints],
        }
