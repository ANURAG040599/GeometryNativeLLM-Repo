from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from .graph import GeometryGraph
from .templates import AVAILABLE_OPS, TransformationStep


@dataclass
class CandidateSolution:
    program: List[TransformationStep]
    score: float
    graph: GeometryGraph
    proof: List[str] = field(default_factory=list)
    valid: bool = False
    explanation: str = ""


class GeometrySearcher:
    def propose(self, graph: GeometryGraph, task: str, memory_hits: List[Dict[str, Any]]) -> List[CandidateSolution]:
        candidates: List[CandidateSolution] = []
        for hit in memory_hits:
            ops = hit.get("program", ["inspect"])
            program = [AVAILABLE_OPS[o] for o in ops if o in AVAILABLE_OPS]
            candidates.append(CandidateSolution(
                program=program,
                score=0.0,
                graph=graph,
                explanation=hit.get("name", "template_match"),
            ))
        if not candidates:
            candidates.append(CandidateSolution(
                program=[AVAILABLE_OPS["inspect"]],
                score=0.0,
                graph=graph,
                explanation="fallback",
            ))
        return candidates

    @staticmethod
    def score_candidate(candidate: CandidateSolution, validity: float, proof_strength: float, similarity: float, cost: float, uncertainty: float) -> float:
        return validity + proof_strength + similarity - cost - uncertainty
