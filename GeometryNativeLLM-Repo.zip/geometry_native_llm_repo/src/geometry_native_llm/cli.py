from __future__ import annotations

import argparse
import json
import sys

from .model import GeometryNativeLLM


def main() -> None:
    parser = argparse.ArgumentParser(description="Geometry-Native LLM prototype")
    parser.add_argument("prompt", nargs="?", help="Prompt to solve")
    args = parser.parse_args()

    prompt = args.prompt or sys.stdin.read().strip()
    if not prompt:
        parser.error("Provide a prompt as an argument or via stdin.")

    model = GeometryNativeLLM()
    result = model.solve(prompt)
    print(json.dumps(result, indent=2))
