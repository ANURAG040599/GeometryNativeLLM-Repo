from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class TransformationStep:
    op: str
    inputs: List[str]
    outputs: List[str]
    preconditions: List[str]
    invariants: List[str]
    cost: float = 0.0


AVAILABLE_OPS: Dict[str, TransformationStep] = {
    "partition_circle": TransformationStep(
        op="partition_circle",
        inputs=["c1"],
        outputs=["sectors"],
        preconditions=["c1.type == Circle"],
        invariants=["area_preserved"],
        cost=0.2,
    ),
    "linearize_arcs": TransformationStep(
        op="linearize_arcs",
        inputs=["sectors"],
        outputs=["strips"],
        preconditions=["sectors exist"],
        invariants=["approx_shape_preserved"],
        cost=0.2,
    ),
    "reassemble_strips": TransformationStep(
        op="reassemble_strips",
        inputs=["strips"],
        outputs=["parallelogram_like_shape"],
        preconditions=["strips exist"],
        invariants=["area_preserved"],
        cost=0.1,
    ),
    "verify_area": TransformationStep(
        op="verify_area",
        inputs=["c1", "s1"],
        outputs=["verified_relation"],
        preconditions=["c1.area == s1.area"],
        invariants=["exact_area_match"],
        cost=0.05,
    ),
    "detect_axis": TransformationStep(
        op="detect_axis",
        inputs=["shape1"],
        outputs=["axis_candidates"],
        preconditions=["shape1 exists"],
        invariants=["symmetry_consistency"],
        cost=0.15,
    ),
    "validate_reflection": TransformationStep(
        op="validate_reflection",
        inputs=["shape1", "axis_candidates"],
        outputs=["symmetry_result"],
        preconditions=["axis_candidates exist"],
        invariants=["reflection_invariance"],
        cost=0.15,
    ),
    "inspect": TransformationStep(
        op="inspect",
        inputs=["x1"],
        outputs=["analysis"],
        preconditions=[],
        invariants=[],
        cost=0.1,
    ),
}
