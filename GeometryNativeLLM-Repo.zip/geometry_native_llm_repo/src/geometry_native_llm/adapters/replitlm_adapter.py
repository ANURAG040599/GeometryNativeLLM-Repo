from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict

from ..model import GeometryNativeLLM


@dataclass
class ReplitLMGeometryAdapter:
    """
    Lightweight adapter that demonstrates how a code LLM could be wrapped
    by a geometry-native reasoning core.
    """
    core: GeometryNativeLLM

    def generate(self, prompt: str) -> Dict[str, Any]:
        return self.core.solve(prompt)
