"""Adapters for external LLMs."""
