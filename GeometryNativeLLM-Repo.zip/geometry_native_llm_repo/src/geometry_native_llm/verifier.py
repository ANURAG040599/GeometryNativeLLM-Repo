from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .graph import GeometryGraph


@dataclass
class VerificationReport:
    valid: bool
    notes: List[str] = field(default_factory=list)


class GeometryVerifier:
    """Checks whether a proposed program matches the graph constraints."""

    def verify(self, graph: GeometryGraph, program: List[str]) -> VerificationReport:
        notes: List[str] = []
        node_map = graph.node_map()

        if any(step == "verify_area" for step in program):
            c1 = node_map.get("c1")
            s1 = node_map.get("s1")
            if not c1 or not s1:
                return VerificationReport(False, ["missing circle/square nodes"])
            circle_area = c1.props.get("area")
            square_area = s1.props.get("area")
            if circle_area is None or square_area is None:
                return VerificationReport(False, ["missing area values"])
            if abs(circle_area - square_area) <= 1e-6:
                notes.append("area verified exactly")
            else:
                return VerificationReport(False, [f"area mismatch: {circle_area} != {square_area}"])

        if any(step == "detect_axis" for step in program):
            notes.append("symmetry analysis requested")

        if not program:
            return VerificationReport(False, ["empty program"])

        return VerificationReport(True, notes)
