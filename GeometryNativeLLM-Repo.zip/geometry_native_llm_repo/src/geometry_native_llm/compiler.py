from __future__ import annotations

import math
import re
from typing import Any, Dict, Optional

from .graph import GeoConstraint, GeoEdge, GeoNode, GeometryGraph


class GeometryCompiler:
    """Turn raw text into a structured geometry graph."""

    def compile(self, raw_input: str) -> Dict[str, Any]:
        text = raw_input.strip().lower()
        signals = {
            "mentions_circle": "circle" in text,
            "mentions_square": "square" in text,
            "mentions_area": "area" in text,
            "mentions_symmetry": "symmetry" in text or "symmetric" in text,
            "mentions_containment": any(k in text for k in ["inside", "contain", "contains", "within"]),
            "mentions_transform": any(k in text for k in ["transform", "convert", "map", "rearrange"]),
        }
        numbers = [float(x) for x in re.findall(r"[-+]?\d*\.\d+|\d+", text)]

        task = "generic"
        if signals["mentions_circle"] and signals["mentions_square"] and signals["mentions_area"]:
            task = "circle_to_square_area_preservation"
        elif signals["mentions_symmetry"]:
            task = "symmetry_detection"
        elif signals["mentions_containment"]:
            task = "containment_reasoning"
        elif signals["mentions_transform"]:
            task = "transformation_reasoning"

        graph = GeometryGraph()

        if task == "circle_to_square_area_preservation":
            r = self._extract_radius(text) or (numbers[0] if numbers else 1.0)
            circle_area = math.pi * r * r
            square_side = math.sqrt(circle_area)
            graph.nodes.extend([
                GeoNode(id="c1", type="Circle", props={"radius": r, "area": circle_area}),
                GeoNode(id="s1", type="Square", props={"side": square_side, "area": circle_area}),
                GeoNode(id="a1", type="Constraint", props={"kind": "preserve_area"}),
            ])
            graph.edges.append(GeoEdge(source="c1", target="s1", type="area_equivalence"))
            graph.constraints.append(GeoConstraint(
                kind="preserve_area",
                subject="c1",
                target="s1",
                params={"expected_area": circle_area},
                hard=True,
            ))
        elif task == "symmetry_detection":
            graph.nodes.extend([
                GeoNode(id="shape1", type="Shape", props={"kind": "unknown"}),
                GeoNode(id="sym1", type="Constraint", props={"kind": "find_symmetry"}),
            ])
            graph.constraints.append(GeoConstraint(kind="find_symmetry", subject="shape1", hard=False, weight=0.7))
        elif task == "containment_reasoning":
            graph.nodes.extend([
                GeoNode(id="a", type="Region", props={"name": "A"}),
                GeoNode(id="b", type="Region", props={"name": "B"}),
                GeoNode(id="c", type="Constraint", props={"kind": "containment"}),
            ])
            graph.constraints.append(GeoConstraint(kind="containment", subject="a", target="b", params={"relation": "inside"}))
        else:
            graph.nodes.extend([
                GeoNode(id="x1", type="AbstractObject", props={}),
                GeoNode(id="x2", type="Constraint", props={"kind": "generic_transform"}),
            ])
            graph.constraints.append(GeoConstraint(kind="generic_transform", subject="x1", hard=False, weight=0.3))

        return {
            "task": task,
            "text": text,
            "signals": signals,
            "numbers": numbers,
            "confidence": 0.65 if any(signals.values()) else 0.2,
            "graph": graph,
        }

    def _extract_radius(self, text: str) -> Optional[float]:
        patterns = [
            r"radius\s*[:=]?\s*(\d*\.\d+|\d+)",
            r"r\s*[:=]?\s*(\d*\.\d+|\d+)",
        ]
        for p in patterns:
            m = re.search(p, text)
            if m:
                return float(m.group(1))
        return None
