from geometry_native_llm.model import GeometryNativeLLM

if __name__ == "__main__":
    model = GeometryNativeLLM()
    prompts = [
        "Transform a circle with radius 2 into an equal-area square.",
        "Find the symmetry axis of this shape.",
        "Describe containment between region A and region B.",
        "Explain a generic transformation.",
    ]
    for prompt in prompts:
        print("\nPROMPT:", prompt)
        print(model.solve(prompt))
