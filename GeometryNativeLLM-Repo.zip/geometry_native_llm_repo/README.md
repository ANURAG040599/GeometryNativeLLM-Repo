# Geometry-Native LLM Repo

A practical prototype of a Geometry-Native core LLM. The repo is intentionally small, runnable, and testable.

## What it does

- Parses text prompts into a structured geometry graph
- Retrieves a reasoning template
- Proposes transformation programs
- Verifies constraints before decoding
- Produces explanations, graph JSON, and traces

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
geometry-native-llm "Transform a circle with radius 2 into an equal-area square."
```

## Run tests

```bash
pytest -q
```

## Files

- `src/geometry_native_llm/graph.py` — graph data model
- `src/geometry_native_llm/compiler.py` — text-to-graph compiler
- `src/geometry_native_llm/reasoner.py` — template search and scoring
- `src/geometry_native_llm/verifier.py` — invariant checks
- `src/geometry_native_llm/model.py` — end-to-end inference loop
- `examples/demo.py` — practical demonstration

## Notes

This is a testable core prototype, not a trained foundation model.
