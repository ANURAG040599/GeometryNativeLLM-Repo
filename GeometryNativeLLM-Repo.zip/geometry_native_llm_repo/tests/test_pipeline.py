from geometry_native_llm.model import GeometryNativeLLM


def test_circle_area_pipeline():
    model = GeometryNativeLLM()
    result = model.solve("Transform a circle with radius 2 into an equal-area square.")
    assert result["task"] == "circle_to_square_area_preservation"
    assert result["valid"] is True
    assert abs(result["graph"]["nodes"][0]["props"]["area"] - 12.566370614359172) < 1e-9
    assert "Circle area is matched against square area." in result["proof"]


def test_symmetry_pipeline():
    model = GeometryNativeLLM()
    result = model.solve("Find the symmetry axis of this shape.")
    assert result["task"] == "symmetry_detection"
    assert result["valid"] is True
    assert "symmetry" in result["answer"].lower()


def test_generic_pipeline():
    model = GeometryNativeLLM()
    result = model.solve("Explain a generic transformation.")
    assert result["task"] == "transformation_reasoning"
    assert result["valid"] is True
    assert "generic geometric reasoning" in result["answer"].lower()
